from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import httpx
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["POST"],
    allow_headers=["*"],
)

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")

SYSTEM_PROMPT = """You are a Toronto TTC transit assistant. Search the web for live TTC service alerts.
Respond ONLY with a raw JSON object (no markdown, no backticks) in this format:
{
  "status": "ok" or "delay",
  "message": "1-2 sentence natural language summary for the user",
  "alerts": [
    {
      "line": "Line 1 Yonge-University",
      "type": "Closure" or "Reduced Service" or "Delay" or "Other",
      "description": "Full alert description",
      "date": "Mar 5, 2026",
      "category": "Maintenance" or "Other"
    }
  ]
}
If no alerts, return "status":"ok" and empty alerts array [].
Always search first. Be accurate. The line field must include the full line name so colours can be applied."""


class ChatRequest(BaseModel):
    message: str


@app.post("/api/chat")
async def chat(req: ChatRequest):
    if not ANTHROPIC_API_KEY:
        raise HTTPException(status_code=500, detail="ANTHROPIC_API_KEY not set on server")

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "Content-Type": "application/json",
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
            },
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 1500,
                "system": SYSTEM_PROMPT,
                "tools": [{"type": "web_search_20250305", "name": "web_search"}],
                "messages": [{"role": "user", "content": req.message}],
            },
        )

    if response.status_code != 200:
        raise HTTPException(status_code=502, detail="Anthropic API error")

    data = response.json()
    text = "".join(b["text"] for b in data.get("content", []) if b["type"] == "text")
    return {"response": text}


app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
