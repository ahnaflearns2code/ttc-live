# TTC Live Updates

A real-time TTC transit chat app powered by Claude AI.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set your Anthropic API key:
```bash
export ANTHROPIC_API_KEY=your_key_here
```

3. Run the server:
```bash
uvicorn main:app --reload
```

4. Open http://localhost:8000 in your browser.

## Deploy

### Railway (recommended - easiest)
1. Push this folder to a GitHub repo
2. Go to railway.app, click New Project > Deploy from GitHub
3. Add environment variable: ANTHROPIC_API_KEY = your key
4. Done! Railway auto-detects Python and deploys.

### Render
1. Push to GitHub
2. Go to render.com > New Web Service > connect repo
3. Build command: 
4. Start command: 
5. Add ANTHROPIC_API_KEY environment variable

### Vercel
Vercel does not support FastAPI well. Use Railway or Render instead.

## Project Structure
```
ttc-app/
  main.py          # FastAPI backend
  requirements.txt # Python dependencies
  frontend/
    index.html     # Chat UI
```
